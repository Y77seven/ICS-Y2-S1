public class WhatDayIsIt {
}
