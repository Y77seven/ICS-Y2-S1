import java.sql.*;

public class SQLDemo {
    // You can replace this with your own MySQL account
    private static String csseURL = "jdbc:mysql://csse-mysql.xjtlu.edu.cn:3306/jianjunchen?user=JianjunChen&password=123";

    /*
        Below is a VERY basic demo of using SQL in a Java application.
     */
    public static void demoBasicSQL() throws SQLException {
        Connection conn = DriverManager.getConnection(csseURL);
        System.out.println("Connected to the database");
        Statement statement = conn.createStatement();

        // create two tables first
        statement.execute("DROP TABLE IF EXISTS staff, branch");
        statement.execute("CREATE TABLE branch (branchID int PRIMARY KEY, address VARCHAR(100) NOT NULL);");
        statement.execute("CREATE TABLE staff (staffID int PRIMARY KEY, salary INT NOT NULL, " +
                "branchID int REFERENCES branch (branchID));");
        System.out.println("tables have been created!");

        // add some tuples
        for (int i = 1; i < 5; i++) {
            String content = "INSERT INTO branch VALUES (" + i + ", 'unknown address')";
            System.out.println("running: " + content);
            statement.execute(content);
            content = "INSERT INTO staff VALUES (" + (i * 1000) + "," + 1000 +"," + i + ")";
            System.out.println("running: " + content);
            statement.execute(content);
        }
        System.out.println("some tuples have been added.");

        // SELECT queries
        String query = "SELECT * FROM staff NATURAL JOIN branch";
        System.out.println("running: " + query);
        statement.execute(query);
        ResultSet rs = statement.getResultSet();
        System.out.println("----------------------------------------------------------------");
        while (rs.next()) {
            System.out.print("Staff ID " + rs.getInt("staffID") + ": ");
            System.out.println("He works in branch " + rs.getInt("branchID")
                    + " and the address is: " + rs.getString("address"));
        }
        System.out.println("----------------------------------------------------------------");

        conn.close();
    }

    /*
        In this demo, we use one thread to update the salaries of two staff members
        and another to sum up the salaries of the staff involved in the update
     */
    public static void demoNoTransaction() {
        new Thread(() -> { // update salaries
            try {
                Connection conn = DriverManager.getConnection(csseURL);
                Statement statement = conn.createStatement();
                for (int i = 0; i < 200; i++) {
                    statement.execute("update staff set salary = salary + 50 where staffID = 1000");
                    statement.execute("update staff set salary = salary - 50 where staffID = 2000");
                }
                conn.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }).start();

        new Thread(() -> { // update salaries
            try {
                Connection conn = DriverManager.getConnection(csseURL);
                Statement statement = conn.createStatement();
                for (int i = 0; i < 3; i++) { // Try 3 times so that we have higher chance of encountering sum up error
                    Thread.sleep(500);
                    statement.execute("SELECT salary FROM staff WHERE staffID in (1000,2000)");
                    ResultSet rs = statement.getResultSet();
                    rs.next();
                    int s1 = rs.getInt("salary");
                    rs.next();
                    int s2 = rs.getInt("salary");
                    System.out.println("Sum of 2 salaries: " + (s1 + s2));
                }
                conn.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }).start();
    }

    /*
        In this demo, we use one thread to update the salaries of two staff members
        and another to sum up the salaries of the staff involved in the update
     */
    public static void demoTransaction() {
        new Thread(() -> { // update salaries
            try {
                Connection conn = DriverManager.getConnection(csseURL);
                Statement statement = conn.createStatement();
                statement.execute("start transaction ");
                for (int i = 0; i < 200; i++) {
                    statement.execute("update staff set salary = salary + 50 where staffID = 1000");
                    statement.execute("update staff set salary = salary - 50 where staffID = 2000");
                }
                statement.execute("commit");
                conn.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }).start();

        new Thread(() -> { // update salaries
            try {
                Connection conn = DriverManager.getConnection(csseURL);
                Statement statement = conn.createStatement();
                for (int i = 0; i < 3; i++) { // Try 3 times so that we have higher chance of encountering sum up error
                    Thread.sleep(500);
                    statement.execute("SELECT salary FROM staff WHERE staffID in (1000,2000)");
                    ResultSet rs = statement.getResultSet();
                    rs.next();
                    int s1 = rs.getInt("salary");
                    rs.next();
                    int s2 = rs.getInt("salary");
                    System.out.println("Some of 2 salaries: " + (s1 + s2));
                }
                conn.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }).start();
    }

    public static void main(String[] args) {
        try {
            demoBasicSQL();
            Thread.sleep(1000);
            //demoNoTransaction();
            demoTransaction();
        } catch (SQLException | InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}